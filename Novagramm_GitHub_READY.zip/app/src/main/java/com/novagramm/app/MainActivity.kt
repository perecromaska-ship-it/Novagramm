package com.novagramm.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.random.Random

data class Chat(val name:String,val message:String)
fun newNvId() = "NV-${Random.nextInt(100,1000)}-${Random.nextInt(100,1000)}-${Random.nextInt(100,1000)}"

class MainActivity: ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { NovagrammApp() }
 }
}

@Composable fun NovagrammApp() {
 var tab by remember { mutableIntStateOf(0) }
 var id by remember { mutableStateOf(newNvId()) }
 var stars by remember { mutableIntStateOf(0) }
 var role by remember { mutableStateOf("USER") }
 val chats = listOf(Chat("Novagramm","Добро пожаловать!"),Chat("Поддержка","Здесь появятся сообщения."))
 MaterialTheme {
  Scaffold(topBar={TopAppBar(title={Text("Novagramm")})},bottomBar={
   NavigationBar {
    NavigationBarItem(tab==0,{tab=0},{Text("Чаты")},{Text("💬")})
    NavigationBarItem(tab==1,{tab=1},{Text("Профиль")},{Text("👤")})
    NavigationBarItem(tab==2,{tab=2},{Text("Панель")},{Text("⚙️")})
   }
  }) { p ->
   when(tab) {
    0 -> LazyColumn(Modifier.fillMaxSize().padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
     items(chats){c->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(c.name,style=MaterialTheme.typography.titleMedium);Text(c.message)}}}
    }
    1 -> Column(Modifier.fillMaxSize().padding(p).padding(20.dp)){
     Text("👤 Профиль",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(16.dp))
     Text("Внутренний ID");Text(id,style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(12.dp))
     Text("⭐ Stars: $stars");Spacer(Modifier.height(20.dp))
     Button({id=newNvId()}){Text("Сгенерировать новый NV-ID")}
    }
    else -> Column(Modifier.fillMaxSize().padding(p).padding(20.dp)){
     Text(if(role=="OWNER")"👑 Owner Panel" else "🛡️ Admin Panel",style=MaterialTheme.typography.headlineMedium)
     Spacer(Modifier.height(12.dp));Text("Роль: $role");Text("Stars: $stars");Spacer(Modifier.height(16.dp))
     Button({stars+=100}){Text("Демо: выдать 100 Stars")}
     Spacer(Modifier.height(8.dp))
     Button({role=if(role=="OWNER")"ADMIN" else "OWNER"}){Text("Переключить демо-роль")}
     Spacer(Modifier.height(20.dp))
     Text("Демо: права владельца в production должны проверяться сервером.")
    }
   }
  }
 }
}
