# Novagramm

Android 14–15 starter messenger project.

## GitHub APK build

This repository includes a GitHub Actions workflow that automatically builds a debug APK on pushes to `main` or `master`, and can also be started manually from the Actions tab.

After the workflow finishes, open the workflow run and download the `Novagramm-debug-apk` artifact.

## Important

This is a starter/demo project, not a production Telegram replacement. Real accounts, server-side authorization, messaging, push notifications, secure storage, media upload, and payment/Stars infrastructure still need a backend.
